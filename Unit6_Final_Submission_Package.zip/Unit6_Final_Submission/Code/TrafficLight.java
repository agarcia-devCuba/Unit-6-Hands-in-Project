import java.util.Scanner;

/*
Unit 6 Hands-On Project 2: TrafficLight
Goal: Create a TrafficLight class with color and duration attributes.
*/
public class TrafficLight {
    private String color;
    private int duration;

    public TrafficLight(String color, int duration) {
        this.color = color.toUpperCase();
        this.duration = duration;
    }

    public void changeColor(String newColor) {
        color = newColor.toUpperCase();
    }

    public boolean isRed() {
        return color.equals("RED");
    }

    public boolean isGreen() {
        return color.equals("GREEN");
    }

    public String toString() {
        return "TrafficLight color: " + color + ", duration: " + duration + " seconds";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        TrafficLight light = new TrafficLight("RED", 30);
        System.out.println(light);
        System.out.println("Is red? " + light.isRed());
        System.out.println("Is green? " + light.isGreen());

        System.out.print("Enter a new color: ");
        String firstColor = input.nextLine();
        light.changeColor(firstColor);
        System.out.println(light);
        System.out.println("Is red? " + light.isRed());
        System.out.println("Is green? " + light.isGreen());

        System.out.print("Enter another new color: ");
        String secondColor = input.nextLine();
        light.changeColor(secondColor);
        System.out.println(light);
        System.out.println("Is red? " + light.isRed());
        System.out.println("Is green? " + light.isGreen());

        input.close();
    }
}
