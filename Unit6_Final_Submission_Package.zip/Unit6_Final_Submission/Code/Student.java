import java.util.ArrayList;
import java.util.Scanner;

/*
Unit 6 Hands-On Project 4: Student
Goal: Create a Student class with name, grade, and a list of courses.
*/
public class Student {
    private String name;
    private String grade;
    private ArrayList<String> courses;

    public Student(String name, String grade) {
        this.name = name;
        this.grade = grade;
        courses = new ArrayList<>();
    }

    public void addCourse(String course) {
        courses.add(course);
        System.out.println(course + " was added.");
    }

    public void removeCourse(String course) {
        if (courses.remove(course)) {
            System.out.println(course + " was removed.");
        } else {
            System.out.println(course + " was not found.");
        }
    }

    public void listCourses() {
        if (courses.isEmpty()) {
            System.out.println("No courses are currently listed.");
        } else {
            System.out.println("Courses:");
            for (String course : courses) {
                System.out.println("- " + course);
            }
        }
    }

    public String toString() {
        return "Student name: " + name + ", grade: " + grade;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String name = input.nextLine();

        System.out.print("Enter student grade: ");
        String grade = input.nextLine();

        Student student = new Student(name, grade);
        System.out.println(student);

        int choice;
        do {
            System.out.println("\nMenu");
            System.out.println("1. Add course");
            System.out.println("2. Remove course");
            System.out.println("3. List courses");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {
                System.out.print("Enter course to add: ");
                String course = input.nextLine();
                student.addCourse(course);
            } else if (choice == 2) {
                System.out.print("Enter course to remove: ");
                String course = input.nextLine();
                student.removeCourse(course);
            } else if (choice == 3) {
                student.listCourses();
            } else if (choice == 4) {
                System.out.println("Goodbye.");
            } else {
                System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 4);

        input.close();
    }
}
