import java.text.DecimalFormat;
import java.util.Scanner;

/*
Unit 6 Hands-On Project 1: MinutesConversion
Goal: Convert an integer number of minutes into hours and days.
*/
public class MinutesConversion {
    public static double convertToHours(int minutes) {
        return minutes / 60.0;
    }

    public static double convertToDays(int minutes) {
        return minutes / 1440.0;
    }

    public static String buildOutput(int minutes, double hours, double days) {
        DecimalFormat formatter = new DecimalFormat("0.###");
        return minutes + " minutes equals " + formatter.format(hours)
                + " hours and equals " + formatter.format(days) + " days.";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of minutes (integer >= 0): ");
        int minutes = input.nextInt();

        if (minutes < 0) {
            System.out.println("Error: minutes cannot be negative.");
            input.close();
            return;
        }

        double hours = convertToHours(minutes);
        double days = convertToDays(minutes);

        System.out.println(buildOutput(minutes, hours, days));

        input.close();
    }
}
