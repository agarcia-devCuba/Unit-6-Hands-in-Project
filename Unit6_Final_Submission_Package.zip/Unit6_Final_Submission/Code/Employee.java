import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

/*
Unit 6 Hands-On Project 3: Employee
Goal: Create an Employee class with name, salary, hire date, and years of service.
*/
public class Employee {
    private String name;
    private double salary;
    private LocalDate hireDate;

    public Employee(String name, double salary, LocalDate hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;
    }

    public int getYearsOfService() {
        return Period.between(hireDate, LocalDate.now()).getYears();
    }

    public String toString() {
        return String.format("Employee name: %s%nSalary: $%.2f%nHire date: %s", name, salary, hireDate);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter employee name: ");
        String name = input.nextLine();

        System.out.print("Enter employee salary: ");
        double salary = input.nextDouble();
        input.nextLine();

        System.out.print("Enter hire date (YYYY-MM-DD): ");
        String dateText = input.nextLine();
        LocalDate hireDate = LocalDate.parse(dateText);

        Employee employee = new Employee(name, salary, hireDate);

        System.out.println(employee);
        System.out.println("Years of service: " + employee.getYearsOfService());

        input.close();
    }
}
